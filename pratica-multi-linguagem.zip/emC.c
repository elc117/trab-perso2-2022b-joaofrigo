#include <stdio.h>

int main(void) {
  printf("Hello World em C!\n");
  return 0;
}